function toggleSidebar() {
    let sidebar = document.getElementById("sidebar");
    if (sidebar.style.left === "0px") {
      sidebar.style.left = "-250px";
    } else {
      sidebar.style.left = "0px";
    }
}

 document.addEventListener('DOMContentLoaded', () => {
    
      const QUESTIONS_TO_SHOW = 5; 

      
    const questions = [
    { 
      q: "What is the main objective of the Knapsack Problem?",
      options: ["To minimize cost", "To maximize profit/value", "To minimize weight", "To maximize number of items"],
      answer: 1
    },
    {
      q: "In the 0/1 Knapsack Problem, each item can be:",
      options: ["Divided into parts", "Taken entirely or left out", "Taken multiple times", "Broken into half"],
      answer: 1
    },
    {
      q: "Which of the following approaches can optimally solve the 0/1 Knapsack Problem?",
      options: ["Greedy Algorithm", "Brute Force", "Dynamic Programming", "Binary Search"],
      answer: 2
    },
    {
      q: "Which type of Knapsack Problem allows taking fractions of items?",
      options: ["0/1 Knapsack", "Fractional Knapsack", "Multiple Knapsack", "Subset Knapsack"],
      answer: 1
    },
    {
      q: "Knapsack is an example of which type of problem?",
      options: ["Sorting", "Optimization", "Traversal", "Searching"],
      answer: 1
    },
    {
      q: "The Greedy approach gives an optimal solution for which type of Knapsack Problem?",
      options: ["0/1 Knapsack", "Fractional Knapsack", "Both A and B", "None of these"],
      answer: 1
    },
    {
      q: "What are the two key parameters for each item in the Knapsack Problem?",
      options: ["Weight and Value", "Weight and Cost", "Value and Profit", "Size and Capacity"],
      answer: 0
    },
    {
      q: "Which of the following is the time complexity of the 0/1 Knapsack using Dynamic Programming?",
      options: ["O(n)", "O(n*W)", "O(n log n)", "O(W^2)"],
      answer: 1
    },
    {
      q: "What is the main limitation of the Greedy approach for the 0/1 Knapsack Problem?",
      options: ["It requires sorting items", "It doesn’t guarantee an optimal solution", "It has high time complexity", "It uses recursion"],
      answer: 1
    },
    {
      q: "Which of the following real-world problems can be modeled as a Knapsack Problem?",
      options: ["Packing a bag to maximize value within weight limit", "Sorting student grades", "Searching for a number in a list", "Finding shortest path in a graph"],
      answer: 0
    }
  ];



      const take = Math.min(QUESTIONS_TO_SHOW, questions.length);


      function shuffle(arr){
        const a = arr.slice();
        for (let i = a.length - 1; i > 0; i--){
          const j = Math.floor(Math.random() * (i + 1));
          [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
      }

 
      const selected = shuffle(questions).slice(0, take);

      const form = document.getElementById('quiz-form');
      selected.forEach((item, idx) => {
        const q = document.createElement('div');
        q.className = 'question';
        q.textContent = `${idx + 1}. ${item.q}`;
        form.appendChild(q);

        const opts = document.createElement('div');
        opts.className = 'options';

        item.options.forEach((opt, i) => {
          const label = document.createElement('label');
          const input = document.createElement('input');
          input.type = 'radio';
          input.name = `q${idx}`;
          input.value = String(i);
          label.appendChild(input);
          label.append(`${opt}`);
          opts.appendChild(label);
        });

        form.appendChild(opts);
      });

      function submitQuiz(){
        let score = 0;
        selected.forEach((item, idx) => {
          const chosen = form.querySelector(`input[name="q${idx}"]:checked`);
          if (chosen && Number(chosen.value) === item.answer) score++;
        });
        document.getElementById('result').textContent =
           `You scored ${score} / ${selected.length}`;
      }

      document.getElementById('submitBtn').addEventListener('click', submitQuiz);
    });
