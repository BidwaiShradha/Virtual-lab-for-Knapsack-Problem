function toggleSidebar() {
  let sidebar = document.getElementById("sidebar");
  if (sidebar.style.left === "0px") {
    sidebar.style.left = "-250px";
  } else {
    sidebar.style.left = "0px";
  }
}

document.addEventListener("DOMContentLoaded", () => {

  // ---------------- State Variables ----------------
  let items = [];
  let isRatioCalculated = false;
  let isSorted = false;

  // ---------------- DOM References ----------------
  const itemNameInput = document.getElementById("itemName");
  const itemWeightInput = document.getElementById("itemWeight");
  const itemProfitInput = document.getElementById("itemProfit");
  const knapsackCapacityInput = document.getElementById("knapsackCapacity");

  const addItemBtn = document.getElementById("addItemBtn");
  const step1Btn = document.getElementById("step1");
  const step2Btn = document.getElementById("step2");
  const step3Btn = document.getElementById("step3");
  const resetBtn = document.getElementById("resetBtn");

  const knapsackContainer = document.getElementById("knapsackContainer");
  const profitDisplay = document.getElementById("totalProfitDisplay");

  // ---------------- Utility Functions ----------------
  function renderTable(list) {
    const tbody = document.querySelector("#itemTable tbody");

    if (list.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4">No items added yet.</td></tr>';
      return;
    }

    tbody.innerHTML = "";
    list.forEach(item => {
      const row = `
        <tr>
          <td>${item.name}</td>
          <td>${item.weight}</td>
          <td>${item.profit}</td>
          <td style="color:${item.ratio ? '#c70039' : 'inherit'}; font-weight:${item.ratio ? 'bold' : 'normal'}">
            ${item.ratio ? item.ratio.toFixed(2) : "-"}
          </td>
        </tr>`;
      tbody.insertAdjacentHTML("beforeend", row);
    });
  }

  function getRandomColor() {
    const colors = ["#007bff", "#28a745", "#ff5733", "#ffb703", "#8e44ad", "#3f51b5", "#00bcd4"];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  function resetSteps() {
    isRatioCalculated = false;
    isSorted = false;
    step2Btn.disabled = true;
    step3Btn.disabled = true;
    knapsackContainer.innerHTML = "";
    profitDisplay.textContent = "";
    renderTable(items);
  }

  function resetAll() {
    items = [];
    knapsackCapacityInput.value = "";
    resetSteps();
  }

  // ---------------- Add Item ----------------
  addItemBtn.addEventListener("click", () => {
    const name = itemNameInput.value.trim();
    const weight = parseFloat(itemWeightInput.value);
    const profit = parseFloat(itemProfitInput.value);

    if (!name || isNaN(weight) || weight <= 0 || isNaN(profit) || profit <= 0) {
      alert("Please enter valid positive values for name, weight, and profit!");
      return;
    }

    items.push({
      name,
      weight,
      profit,
      ratio: 0,
      color: getRandomColor()
    });

    itemNameInput.value = "";
    itemWeightInput.value = "";
    itemProfitInput.value = "";

    resetSteps();
  });

  // ---------------- Step 1: Calculate Ratio ----------------
  step1Btn.addEventListener("click", () => {
    if (items.length < 3) {
      alert("Please add at least 3 items to proceed!");
      return;
    }

    items.forEach(item => {
      item.ratio = item.profit / item.weight;
    });

    renderTable(items);
    isRatioCalculated = true;
    step2Btn.disabled = false;

    alert("Step 1 Complete: Profit/Weight calculated!");
  });

  // ---------------- Step 2: Sort ----------------
  step2Btn.addEventListener("click", () => {
    if (!isRatioCalculated) {
      alert("Please complete Step 1 first!");
      return;
    }

    items.sort((a, b) => b.ratio - a.ratio);
    renderTable(items);

    isSorted = true;
    step3Btn.disabled = false;

    alert("Step 2 Complete: Items sorted by Profit/Weight!");
  });

  // ---------------- Step 3: Fill Knapsack ----------------
  step3Btn.addEventListener("click", () => {
    if (!isSorted) {
      alert("Please complete Step 2 first!");
      return;
    }

    const capacity = parseFloat(knapsackCapacityInput.value);

    if (isNaN(capacity) || capacity <= 0) {
      alert("Enter a valid knapsack capacity!");
      knapsackCapacityInput.focus();
      return;
    }

    const totalItemWeight = items.reduce((sum, item) => sum + item.weight, 0);

    if (capacity >= totalItemWeight) {
      alert(
        `Knapsack capacity must be LESS than total item weight (${totalItemWeight.toFixed(2)})`
      );
      knapsackCapacityInput.focus();
      return;
    }

    let remaining = capacity;
    let totalProfit = 0;
    knapsackContainer.innerHTML = "";

    items.forEach((item, index) => {
      if (remaining <= 0) return;

      let takenWeight;
      let fraction = 1;

      if (item.weight <= remaining) {
        takenWeight = item.weight;
        remaining -= item.weight;
      } else {
        fraction = remaining / item.weight;
        takenWeight = remaining;
        remaining = 0;
      }

      totalProfit += item.profit * fraction;

      if (takenWeight > 0) {
        const box = document.createElement("div");
        box.classList.add("item-box");

        box.style.backgroundColor = item.color;
        box.style.height = `${(takenWeight / capacity) * 100}%`;
        box.style.width = `${(takenWeight / capacity) * 360}px`;
        box.style.flexGrow = "0";

        setTimeout(() => {
          box.style.transform = "scaleY(1)";
        }, index * 300);

        box.textContent = `${item.name} (${takenWeight.toFixed(1)}w)`;
        knapsackContainer.appendChild(box);
      }
    });

    profitDisplay.textContent = `Total Maximum Profit: ${totalProfit.toFixed(2)}`;
    alert(`Step 3 Complete! Total Profit = ${totalProfit.toFixed(2)}`);
  });

  // ---------------- Reset ----------------
  resetBtn.addEventListener("click", () => {
    resetAll();
    alert("Knapsack simulation reset!");
  });

  resetAll();
});
