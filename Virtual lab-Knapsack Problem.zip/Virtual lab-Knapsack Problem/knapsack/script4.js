function toggleSidebar() {
  let sidebar = document.getElementById("sidebar");
  sidebar.style.left = (sidebar.style.left === "0px") ? "-250px" : "0px";
}

document.addEventListener("DOMContentLoaded", () => {

  const QUESTIONS_TO_SHOW = 5;
  const form = document.getElementById("quiz-form");
  const resultDiv = document.getElementById("result");

  const questions = [



{
  q: "What is the main objective of the Knapsack Problem?",
  options: ["Minimize cost", "Maximize profit/value", "Minimize weight", "Maximize items"],
  answer: 1,
  level: "beginner"
},
{
  q: "In 0/1 Knapsack, an item can be:",
  options: ["Divided", "Taken or left", "Repeated", "Broken"],
  answer: 1,
  level: "beginner"
},
{
  q: "Which knapsack allows fractional items?",
  options: ["0/1", "Fractional", "Multiple", "Subset"],
  answer: 1,
  level: "beginner"
},
{
  q: "Knapsack problem belongs to which category?",
  options: ["Sorting", "Optimization", "Traversal", "Searching"],
  answer: 1,
  level: "beginner"
},
{
  q: "Which parameter restricts the knapsack?",
  options: ["Profit", "Value", "Weight", "Cost"],
  answer: 2,
  level: "beginner"
},
{
  q: "Each item in knapsack has:",
  options: ["Only value", "Only weight", "Weight and value", "Capacity"],
  answer: 2,
  level: "beginner"
},
{
  q: "0/1 Knapsack means:",
  options: ["Fraction allowed", "Item chosen once or not", "Unlimited items", "Repeated items"],
  answer: 1,
  level: "beginner"
},
{
  q: "Which approach is simplest for knapsack?",
  options: ["Greedy", "Dynamic Programming", "Backtracking", "Divide and Conquer"],
  answer: 0,
  level: "beginner"
},
{
  q: "What is the input of knapsack problem?",
  options: ["Only weights", "Only profits", "Weights and profits", "Capacity only"],
  answer: 2,
  level: "beginner"
},
{
  q: "Which is a real-life example of knapsack?",
  options: [
    "Sorting marks",
    "Packing bag with max value",
    "Searching roll number",
    "Finding shortest path"
  ],
  answer: 1,
  level: "beginner"
},
{
  q: "Knapsack problem helps in:",
  options: ["Data storage", "Decision making", "Searching", "Sorting"],
  answer: 1,
  level: "beginner"
},
{
  q: "Fractional knapsack can be solved using:",
  options: ["Greedy", "DP", "Backtracking", "DFS"],
  answer: 0,
  level: "beginner"
},
{
  q: "In knapsack, profit means:",
  options: ["Cost", "Value gained", "Weight", "Capacity"],
  answer: 1,
  level: "beginner"
},
{
  q: "Knapsack problem is studied in:",
  options: ["OS", "DAA", "DBMS", "CN"],
  answer: 1,
  level: "beginner"
},
{
  q: "Which knapsack does NOT allow repetition?",
  options: ["Unbounded", "Fractional", "0/1", "Multiple"],
  answer: 2,
  level: "beginner"
},



{
  q: "Which algorithm gives optimal solution for 0/1 Knapsack?",
  options: ["Greedy", "Brute Force", "Dynamic Programming", "Binary Search"],
  answer: 2,
  level: "advanced"
},
{
  q: "Time complexity of DP based 0/1 Knapsack is:",
  options: ["O(n)", "O(nW)", "O(n log n)", "O(W²)"],
  answer: 1,
  level: "advanced"
},
{
  q: "Why greedy fails for 0/1 Knapsack?",
  options: [
    "Sorting issue",
    "Does not explore all combinations",
    "Uses recursion",
    "High space usage"
  ],
  answer: 1,
  level: "advanced"
},
{
  q: "DP solution of knapsack uses:",
  options: ["1D array", "2D table", "Stack", "Queue"],
  answer: 1,
  level: "advanced"
},
{
  q: "Space complexity of DP knapsack is:",
  options: ["O(n)", "O(W)", "O(nW)", "O(log n)"],
  answer: 2,
  level: "advanced"
},
{
  q: "Which problem is closely related to knapsack?",
  options: ["Sorting", "Subset Sum", "Searching", "Graph traversal"],
  answer: 1,
  level: "advanced"
},
{
  q: "Which knapsack allows unlimited items?",
  options: ["0/1", "Fractional", "Unbounded", "Subset"],
  answer: 2,
  level: "advanced"
},
{
  q: "DP knapsack uses which principle?",
  options: [
    "Greedy choice",
    "Optimal substructure",
    "Divide & conquer",
    "Backtracking"
  ],
  answer: 1,
  level: "advanced"
},
{
  q: "Worst-case time complexity of brute force knapsack?",
  options: ["O(n)", "O(2ⁿ)", "O(n log n)", "O(n²)"],
  answer: 1,
  level: "advanced"
},
{
  q: "Which knapsack problem is NP-Complete?",
  options: ["Fractional", "0/1", "Unbounded", "Multiple"],
  answer: 1,
  level: "advanced"
},
{
  q: "Knapsack DP table dimension is:",
  options: ["n × n", "W × W", "n × W", "n × logW"],
  answer: 2,
  level: "advanced"
},
{
  q: "Fractional knapsack uses sorting based on:",
  options: ["Weight", "Value", "Value/Weight", "Capacity"],
  answer: 2,
  level: "advanced"
},
{
  q: "Which approach guarantees optimality for all knapsack variants?",
  options: ["Greedy", "DP", "Backtracking", "Sorting"],
  answer: 1,
  level: "advanced"
},
{
  q: "Which knapsack variant is polynomial-time solvable?",
  options: ["0/1", "Fractional", "Subset", "Bounded"],
  answer: 1,
  level: "advanced"
},
{
  q: "Knapsack problem demonstrates:",
  options: [
    "Overlapping subproblems",
    "Optimal substructure",
    "Both A and B",
    "None"
  ],
  answer: 2,
  level: "advanced"
}

];


  function shuffle(arr) {
    return arr.sort(() => Math.random() - 0.5);
  }

  function loadQuiz(level) {
    form.innerHTML = "";
    resultDiv.textContent = "";

    let que = (level === "all")
      ? [...questions]
      : questions.filter(q => q.level === level);

    const selected = shuffle(que).slice(0, QUESTIONS_TO_SHOW);

    selected.forEach((item, idx) => {
      const qDiv = document.createElement("div");
      qDiv.className = "question";
      qDiv.textContent = `${idx + 1}. ${item.q}`;
      form.appendChild(qDiv);

      const optDiv = document.createElement("div");
      optDiv.className = "options";

      item.options.forEach((opt, i) => {
        const label = document.createElement("label");
        const input = document.createElement("input");

        input.type = "radio";
        input.name = `q${idx}`;
        input.value = i;

        label.appendChild(input);
        label.append(opt);
        optDiv.appendChild(label);
      });

      form.appendChild(optDiv);
    });

    document.getElementById("submitBtn").onclick = () => {
      let score = 0;
      selected.forEach((item, idx) => {
        const chosen = form.querySelector(`input[name="q${idx}"]:checked`);
        if (chosen && Number(chosen.value) === item.answer) score++;
      });
      resultDiv.textContent = `You scored ${score} / ${selected.length}`;
    };
  }

  document.querySelectorAll("input[name='level']").forEach(radio => {
    radio.addEventListener("change", e => loadQuiz(e.target.value));
  });

  loadQuiz("all"); 
});
